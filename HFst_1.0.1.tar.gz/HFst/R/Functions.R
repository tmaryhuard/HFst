#' FindPathToAnc
#'
#' @param Pop A string providing the name of the pop
#' @param ChildPop The children vector in the given tree
#' @param ParentPop The parent vector in the given tree
#' @param Ref The reference node
#'
#' @return A path from the Pop to the Reference node
FindPathToAnc <- function(Pop,ChildPop,ParentPop,Ref='Cl1'){
  Path <- CurrPop <- c(Pop)
  while (CurrPop != Ref) {
    CurrPop <- ParentPop[ChildPop==CurrPop]
    Path <- c(Path,CurrPop)
  }
  return(Path)
}

#' InferThetaFromTree
#'
#' @param LogMoments.L A matrix of log H-moments
#' @param Tree An Htree
#'
#' @return A list containing Beta estimates along with the value of the NNLS criterion
InferThetaFromTree <- function(LogMoments.L,Tree){

  #Get the pair pop names
  LMnames <- strsplit(names(LogMoments.L),'-')
  Pop1 <- sapply(LMnames, function(pair) pair[1])
  Pop2 <- sapply(LMnames, function(pair) pair[2])

  #Get cluster numbers from Tree
  ChildPop <- as.character(Tree$Pop)
  ParentPop <- as.character(Tree$Parent)

  #Build the incidence matrix
  Theta <- matrix(0,length(LogMoments.L),length(ChildPop)-1)
  ThetaColNames <- paste(ChildPop,ParentPop,sep='-')[-1]
  invisible(sapply(1:length(LMnames), function(pair){

    #1-Find paths and MRCA
    Path1 <- FindPathToAnc(Pop1[pair],ChildPop,ParentPop)
    Path2 <- FindPathToAnc(Pop2[pair],ChildPop,ParentPop)
    MRCA <- Path1[which(Path1%in%Path2)][1]

    #2-Update the incidence matrix
    sapply(1:(which(Path1==MRCA)-1), function(ii){
      Theta[pair,ThetaColNames==paste(Path1[ii],Path1[ii+1],sep='-')] <<- 1
    })
  }))

  #Perform inference
  res <- NNLScpp(-Theta,LogMoments.L,Init=rep(0,ncol(Theta)))
  Crit <- res$SSq
  BetaHat <- res$BetaHat
  row.names(BetaHat) <- ThetaColNames
  return(list(BetaHat=BetaHat,Crit=Crit))
}

#' RelocateACandidate
#'
#' @param LogMoments.L A matrix of log H-moments
#' @param Tree An Htree
#' @param PopCand A string providing the name of the candidate population
#'
#' @return An improved tree
RelocateACandidate <- function(LogMoments.L,Tree,PopCand){

  #Find the parent, grandparent and sib pop of PopCand
  ChildPop <- as.character(Tree$Pop)
  ParentPop <- as.character(Tree$Parent)
  ParentCand <- ParentPop[ChildPop==PopCand]
  if (ParentCand != 'Cl1'){
    GrandParentCand <- ParentPop[ChildPop==ParentCand]
  }
  SibCand <- ChildPop[ParentPop==ParentCand]
  SibCand <- SibCand[!(is.na(SibCand)|(SibCand==PopCand))]

  #Remove PopCand from the tree and collapse
  ModParentPop <- ParentPop
  if (ParentCand != 'Cl1'){
    NewParentCand <- ParentCand
    ModParentPop[ChildPop==SibCand] <- GrandParentCand
  } else {
    NewParentCand <- SibCand
    ModParentPop[ChildPop==PopCand] <- NewParentCand
    ModParentPop[ParentPop==SibCand] <- 'Cl1'
  }

  #Now try to put PopCand somewhere...
  Res <- lapply(ChildPop, function(sib){

    #Get rid of the case Cl1
    if(sib=='Cl1'){
      return(list(Crit=Inf))
    }
    if(sib==NewParentCand){
      return(list(Crit=Inf))
    }
    if(sib==PopCand){
      return(list(Crit=Inf))
    }
    #If clusters of 2 are allowed to move...
    if(substr(PopCand,1,2)=='Cl'){
      if(sib%in%ChildPop[ParentPop==PopCand]){
        return(list(Crit=Inf))
      }
    }

    #Find the parent of sib and put PopCand in between
    LocModParentPop <- ModParentPop
    NewGrandParentCand <- LocModParentPop[ChildPop==sib]
    LocModParentPop[ChildPop==NewParentCand] <- NewGrandParentCand
    LocModParentPop[ChildPop==sib] <- NewParentCand
    ModTree <- data.frame(Pop=ChildPop,Parent=LocModParentPop)
    Res <- InferThetaFromTree(LogMoments.L,ModTree)
    return(list(Tree=ModTree,Crit=Res$Crit,BetaHat=Res$BetaHat))
  })
  Best <- which.min(sapply(Res, function(u) u$Crit))
  return(Res[[Best]])
}

#' ImproveTheTree
#'
#' @param LogMoments.L A matrix of log H-moments
#' @param Tree An HTree
#' @param BetaHat A vector of Beta estimates
#' @param Hist An History data.frame
#' @param Crit The value of the NNLS criterion for the HTree provided
#' @param PopNames A list of candidate population names
#'
#' @return A list of 4 objects: Tree, BetaHat, Hist and Crit
ImproveTheTree<- function(LogMoments.L, Tree,BetaHat,Hist,Crit, PopNames){

  cat('Initial fit criterion: ',Crit,'\n')
  Improvement <- 1
  while(Improvement>0.0005){

    #Define a list of Candidates
    ListOfCand <- PopNames
    # Parent <- as.character(Tree$Parent)
    # Child <- as.character(Tree$Pop)
    # Which2 <- sapply(Child[1:(length(PopNames)-1)], function(clus){
    #     sum(Child[Parent==clus]%in%PopNames)==2
    # })
    # ListOfCand <- c(PopNames,names(Which2)[Which2])

    #Then check which is best
    #CheckAllCand <- lapply(ListOfCand, RelocateACandidate, LogMoments.L=LogMoments.L,Tree=Tree)
    CheckAllCand <- future_map(ListOfCand, ~ RelocateACandidate(LogMoments.L=LogMoments.L,Tree=Tree,PopCand = .x))
    BestCand <- which.min(sapply(CheckAllCand, function(u) u$Crit))
    Improvement <- (Crit-CheckAllCand[[BestCand]]$Crit)/Crit
    if(Improvement>0.01){
      cat('Best Candidate for improvement: ',ListOfCand[BestCand],'\n')
      cat('        Improved fit criterion: ',CheckAllCand[[BestCand]]$Crit,'\n')
      Tree <- CheckAllCand[[BestCand]]$Tree
      BetaHat <- CheckAllCand[[BestCand]]$BetaHat
      Crit <- CheckAllCand[[BestCand]]$Crit
    } else {
      cat('No other improvement found.');Improvement <- 0
    }
  }

  ## Update Hist (create the good cluster, then reorder the lines)
  NewHist <- Hist
  Nodes <- Hist[,1]
  invisible(sapply(Nodes, function(node){
    Children <- which(Tree[,2]==node)
    NewHist[NewHist[,1]==node,-1] <<- Tree[Children,1]
  }))
  invisible(sapply(NewHist[-1,1], function(cl){
    Row <- which(NewHist[,1]==cl)
    Before <- which((NewHist[1:Row,2]==cl)|(NewHist[1:Row,3]==cl))
    if (length(Before)>0){
      Before <- min(Before)
      if (Before == 1){
        NewHist <<- rbind(NewHist[Row,],NewHist[-Row])
      } else {
        NewHist <<- rbind(NewHist[1:(Before-1),],NewHist[Row,],NewHist[-Row,][Before:(nrow(NewHist)-1),])
      }
    }
  }))
  return(list(Tree=Tree,BetaHat=BetaHat,Hist=NewHist,Crit=Crit))
}


#' Inner function to update the clustering numbering after improvement of the tree.
#'
#' @param Tree a tree as obtained from ImproveTheTree
#' @param BetaHat a set of coefficients as obtained from ImproveTheTree
#' @param Hist a History data.frame as obtained from ImproveTheTree
#' @importFrom rlang .data
#' @return Relabeled versions of Tree, BetaHat and Hist
#'
RelabelTheTree <- function(Tree,BetaHat,Hist){

  ## Declare some functions
  ToNum <- function(strg){
    out <- str_remove(strg,pattern = 'Cl') %>%
      as.numeric
    out[is.na(out)] <- Inf
    return(out)
  }
  ReplaceInHistOrTree <- function(Object,Name,Repl){
    map(Object, ~str_replace(.,pattern = Name,replacement = Repl)) %>%
      bind_cols() %>%
      as.data.frame()
  }
  ReplaceInBetaHat <- function(BH,Name,Repl){
    row.names(BH) <- str_replace(row.names(BH),pattern = Name,replacement = Repl)
    BH
  }

  ## Basic quantities
  AnyPb <- map(Hist,~str_detect(.x,pattern = 'Cl')) %>%
    map2(Hist,., ~ {tmp = str_remove(.x,pattern = 'Cl'); tmp[!.y] <- Inf; as.numeric(tmp)}) %>%
    bind_cols %>%
    mutate(Pb = (.data$Clusters>.data$Member1)|(.data$Clusters>.data$Member2)) %>%
    pull('Pb') %>%
    which

  while(length(AnyPb)>0){

    #Find the first gap
    Row <- AnyPb[1]
    ActualName <- Hist$Clusters[Row]
    if(ToNum(Hist$Clusters[Row])>ToNum(Hist$Member1[Row])){
      AltName <- Hist$Member1[Row]
    } else {
      AltName <- Hist$Member2[Row]
    }

    ## Update Hist
    Hist <- Hist %>%
      ReplaceInHistOrTree(.,ActualName,'XXXXX') %>%
      ReplaceInHistOrTree(.,AltName,ActualName) %>%
      ReplaceInHistOrTree(.,'XXXXX',AltName)

    ## Update Tree
    Tree <- Tree %>%
      ReplaceInHistOrTree(.,ActualName,'XXXXX') %>%
      ReplaceInHistOrTree(.,AltName,ActualName) %>%
      ReplaceInHistOrTree(.,'XXXXX',AltName)

    ## Update BetaHat
    BetaHat <- BetaHat %>%
      ReplaceInBetaHat(.,ActualName,'XXXXX') %>%
      ReplaceInBetaHat(.,AltName,ActualName) %>%
      ReplaceInBetaHat(.,'XXXXX',AltName)

    ## Do it again ?
    AnyPb <- map(Hist,~str_detect(.x,pattern = 'Cl')) %>%
      map2(Hist,., ~ {tmp = str_remove(.x,pattern = 'Cl'); tmp[!.y] <- Inf; as.numeric(tmp)}) %>%
      bind_cols %>%
      mutate(Pb = (.data$Clusters>.data$Member1)|(.data$Clusters>.data$Member2)) %>%
      pull('Pb') %>%
      which
  }
  Hist <- Hist[order(ToNum(Hist$Clusters),decreasing = TRUE),]
  Tree[1:nrow(Hist),] <- Tree[1:nrow(Hist),][order(ToNum(Tree$Pop[1:nrow(Hist)])),]
  return(list(Tree=Tree,BetaHat=BetaHat,Hist=Hist))
}


#Fst and tree inference for populations with unknown tree-structure
# This version :
# - perform NNLS inference with KKT accounted for
# - correctly produce the clustering history
# - handle different data counts for each snp
# - compute the Fst coefficients
#' HFst.clust
#'
#' @param LogMoments An asymmetric matrix of log H-moments
#' @param Improve A boolean: should the initial tree be improved or not? Default is TRUE
#' @description Infer the tree and the theta coefficients for a set of populations based on their log H-moments.
#' @return A list of 5 objects: Tree is a data.frame containing the inferred tree structure - also called the HTree,
#' ThetaHat is a vector of inferred Theta coefficients, Hist is a data.frame that provides the clustering history,
#' Fst is a matrix of pairwise Weir and Hill Fst coefficients, and Crit is the value of the NNLS criterion obtained
#' for the tree.
#' @export
#' @examples
#' data(LogMoment.mat)
#' HTree <- HFst.clust(LogMoments=LogMoment.mat,Improve=FALSE)
HFst.clust <- function(LogMoments,Improve=TRUE){

  #Checks
  if (!(is.matrix(LogMoments)|is.data.frame(LogMoments))){
    stop("LogMoments should be either a matrix or a data.frame")
  }
  if (is.data.frame(LogMoments)){
    LogMoments <- as.matrix(LogMoments)
  }
  if(ncol(LogMoments)!=nrow(LogMoments)){stop("LogMoments is not square")}
  if(!identical(colnames(LogMoments),row.names(LogMoments))){stop("colnames and rownames should be identical")}

  #Define basic quantities
  PopNames <- colnames(LogMoments)
  Groups <- as.list(PopNames)
  names(Groups) <- PopNames
  NbPop <- length(PopNames)
  Coord <- upper.tri(LogMoments)|lower.tri(LogMoments)
  LogMoments.L <- as.vector(LogMoments[Coord])

  #Some make-up
  NbObs <- length(LogMoments.L)
  FirstPop <- matrix(PopNames,NbPop,NbPop)[Coord]
  SecondPop <-t(matrix(PopNames,NbPop,NbPop))[Coord]

  #Initialization
  Theta <- sapply(1:NbPop, function(u) as.numeric((FirstPop==PopNames[u])) )
  ThetaNames <- matrix(NA,2*NbPop-2,2)
  ThetaNames[1:NbPop,] <- cbind(PopNames,rep('Cl1',NbPop))
  Init <- NNLScpp(-Theta,LogMoments.L,rep(0,ncol(Theta)))
  BetaHat <- Init$BetaHat
  Residuals <- -Init$Residuals
  Crit <- Init$SSq

  #Perform clustering
  if (NbPop>2){
    LengthHist <- NbPop-1
    Hist <- data.frame(Clusters=paste0('Cl',(NbPop-1):1),Member1=rep(NA,LengthHist),Member2=rep(NA,LengthHist))
  } else {
    LengthHist <- 1
    Hist <- data.frame(Clusters='Cl1',Member1=PopNames[1],Member2=PopNames[2])
  }
  cpt <- 1
  while(length(Groups)>2){

    #Compute criterion for all potential candidates
    Candidates <- t(combn(names(Groups),2))
    Resume <- data.frame(Gp1=rep('CCC',nrow(Candidates)),Gp2=rep('CCC',nrow(Candidates)),NbTarget=rep(0,nrow(Candidates)),Crit=rep(0,nrow(Candidates)),stringsAsFactors = F)
    CandidatesCrit <- sapply(1:nrow(Candidates),function(u){
      ListAffectedPop <- c(Groups[[Candidates[u,1]]],Groups[[Candidates[u,2]]])
      NbAffected <- length(ListAffectedPop)
      NewCol <- as.numeric((FirstPop%in%ListAffectedPop)&(!(SecondPop%in%ListAffectedPop)))
      NNLSLoc <- NNLScpp(-cbind(Theta,NewCol),LogMoments.L,Init=c(BetaHat,0))
      Weight <- NbAffected*(NbAffected-1)
      CritLoc <- (NNLSLoc$SSq -Crit)/Weight
      Resume[u,] <<- c(Candidates[u,1],Candidates[u,2],Weight,NNLSLoc$SSq -Crit)
      return(CritLoc)
    })

    #Choose the best one
    Best <- which.min(CandidatesCrit)
    ListAffectedPop <- c(Groups[[Candidates[Best,1]]],Groups[[Candidates[Best,2]]])

    #Update
    Theta <- cbind(Theta,as.numeric((FirstPop%in%ListAffectedPop)&(!(SecondPop%in%ListAffectedPop))))
    res <- NNLScpp(-Theta,LogMoments.L,Init=c(BetaHat,0))
    Crit <- res$SSq
    BetaHat <- res$BetaHat
    Residuals <- -res$Residuals
    # print(paste0("Crit = ",Crit))
    Groups[[paste0('Cl',NbPop-cpt)]] <- c(Groups[[Candidates[Best,1]]],Groups[[Candidates[Best,2]]])
    Groups[[Candidates[Best,1]]] <- NULL
    Groups[[Candidates[Best,2]]] <- NULL
    ThetaNames[which(ThetaNames[,1]%in%Candidates[Best,]),2] <- paste0('Cl',NbPop-cpt)
    ThetaNames[NbPop+cpt,] <- c(paste0('Cl',NbPop-cpt),'Cl1')
    Hist[cpt,2:3] <- Candidates[Best,]
    cpt <- cpt + 1
  }
  if(NbPop>2){
    Hist[nrow(Hist),2:3] <- names(Groups)
  }

  #Some make-up
  if (NbPop>2){
    Tree <- ThetaNames[c((2*NbPop-2):(NbPop+1),1:NbPop),]
    Tree <- rbind(c('Cl1',NA),Tree)
  } else {
    Tree <- ThetaNames
    Tree <- rbind(c('Cl1',NA),Tree)
  }
  colnames(Tree) <- c('Pop','Parent')
  names(LogMoments.L) <- row.names(Residuals) <- paste(FirstPop,SecondPop,sep='-')
  Tree=as.data.frame(Tree)

  #Improve the tree
  if (Improve){
    Improved <- ImproveTheTree(LogMoments.L, Tree,BetaHat,Hist,Crit, PopNames)
    # Tree <- Improved$Tree
    # BetaHat <- Improved$BetaHat
    Crit <- Improved$Crit
    # Hist <- Improved$Hist
    Relabeled <- RelabelTheTree(Improved$Tree,Improved$BetaHat,Improved$Hist)
    Tree <- Relabeled$Tree
    BetaHat <- Relabeled$BetaHat
    Hist <- Relabeled$Hist
  } else {
    rownames(BetaHat) <- paste(ThetaNames[,1],ThetaNames[,2],sep='-')
  }
  Tree <- as.matrix(Tree)

  #Compute the Theta coefficients
  ThetaHat <- 1-exp(-BetaHat)
  rownames(ThetaHat) <- row.names(BetaHat)


  #Compute the Fst coefficients
  Child <- Tree[,1]
  Parent <- Tree[,2]
  ParentPathList <- lapply(PopNames, function(u){
    ParentPath <- c()
    CurrNode <- u
    while(CurrNode != 'Cl1'){
      ParentNode <- Parent[Child==CurrNode]
      ParentPath <- c(ParentPath,paste(CurrNode,ParentNode,sep='-'))
      CurrNode <- ParentNode
    }
    return(ParentPath)
  })
  Fst <- matrix(NA,NbPop,NbPop)
  Pairs <- rbind(matrix(1:NbPop,NbPop,2),t(combn(1:NbPop,2)))
  invisible(sapply(1:nrow(Pairs), function(u){
    C1 <- Pairs[u,1]
    C2 <- Pairs[u,2]
    CommonPath <- ParentPathList[[C1]][ParentPathList[[C1]]%in%ParentPathList[[C2]]]
    if(length(CommonPath)>0){
      Fst[C2,C1] <<- Fst[C1,C2] <<- Reduce('*',1-ThetaHat[rownames(ThetaHat)%in%CommonPath])
    } else {
      Fst[C2,C1] <<- Fst[C1,C2] <<- 1
    }
  }))
  Fst <- 1-Fst
  colnames(Fst) <- rownames(Fst) <- PopNames

  Result <- list(Tree=Tree,ThetaHat=ThetaHat,Hist=Hist,Fst=Fst,Crit=Crit)
  return(Result)

}

