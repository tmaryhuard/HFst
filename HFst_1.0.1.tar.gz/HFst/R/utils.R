#' @import utils
## quiets concerns of R CMD check re: the .'s that appear in pipelines
#if(getRversion() >= "2.15.1")  utils::globalVariables(c(".",">"))
if(getRversion() >= "2.15.1")  utils::globalVariables(c("."))


#' FstWH
#' @description Compute Weir & Hill Fst coefficient for a couple of populations in a fully known history tree
#' @param Pair a vector of size 2 containing the names of the 2 populations
#' @param HTree An history tree, as obtained from the HFst.clust function
#' @param Theta A vector of coefficients as obtained from the HFst.clust function
#'
#' @return An estimate of the Weir and Hill Fst coefficient
#' @export
#' @examples
#' #' data(LogMoment.mat)
#' HTree <- HFst.clust(LogMoments=LogMoment.mat,Improve=FALSE)
#' FstWH(c("IBS","TSI"),HTree$Tree,HTree$Theta)
FstWH <- function(Pair,HTree,Theta){

    #Get the right formats
    if(is.vector(Theta)){
        Noms <- names(Theta)
        Theta <- matrix(Theta,ncol=1)
        row.names(Theta) <- Noms
    }
    Tree <- as.data.frame(HTree)
    if(!is.factor(Tree$Pop)){Tree$Pop <- factor(Tree$Pop)}
    if(!is.factor(Tree$Parent)){Tree$Parent <- factor(Tree$Parent)}

    #Build basic quantities
    Path <- list()
    Child <- levels(Tree$Pop)[Tree$Pop]
    Parent <- levels(Tree$Parent)[Tree$Parent]

    #For each of the two nodes, find the path to ancestor
    for (ii in 1:2){
        Which <- which(Child==Pair[ii])
        Path[[ii]] <- Pair[ii]
        CurrParent <- Parent[Which]
        while ((CurrParent != "1")&(CurrParent != "Cl1")){
            Which <- which(Child==CurrParent)
            Path[[ii]] <- c(Path[[ii]], CurrParent)
            CurrParent <- Parent[Which]
        }
        Path[[ii]] <- c(Path[[ii]], CurrParent)
    }

    #Find the common part of these 2 paths
    Common <- Path[[1]][Path[[1]]%in%Path[[2]]]

    if (length(Common)==1){
        Fst=0
    } else {
        ListTheta <- list()
        #Get the common thetas
        for (ii in 1:(length(Common)-1)){
            ListTheta[[ii]] <- 1-Theta[row.names(Theta)==paste(Common[ii],Common[ii+1],sep='-')]
        }
        Fst = 1 - Reduce('*',ListTheta)
    }
    return(Fst)
}

#' FstHudson
#' @description Compute Hudson Fst coefficient for a couple of populations in a fully known history tree
#' @param Pair a vector of size 2 containing the names of the 2 populations
#' @param HTree An history tree, as obtained from the HFst.clust function
#' @param Theta A vector of coefficients as obtained from the HFst.clust function
#'
#' @return An estimated Hudson Fst coefficient
#' @export
#' @examples
#' data(LogMoment.mat)
#' HTree <- HFst.clust(LogMoments=LogMoment.mat,Improve=FALSE)
#' FstHudson(c("STU","TSI"),HTree$Tree,HTree$Theta)

FstHudson <- function(Pair,HTree,Theta){

    #Get the right formats
    if(is.vector(Theta)){
        Noms <- names(Theta)
        Theta <- matrix(Theta,ncol=1)
        row.names(Theta) <- Noms
    }
    Tree <- as.data.frame(HTree)
    if(!is.factor(Tree$Pop)){Tree$Pop <- factor(Tree$Pop)}
    if(!is.factor(Tree$Parent)){Tree$Parent <- factor(Tree$Parent)}

    #Build basic quantities
    Path <- list()
    Child <- levels(Tree$Pop)[Tree$Pop]
    Parent <- levels(Tree$Parent)[Tree$Parent]

    #For each of the two nodes, find the path to ancestor
    for (ii in 1:2){
        Which <- which(Child==Pair[ii])
        Path[[ii]] <- Pair[ii]
        CurrParent <- Parent[Which]
        while ((CurrParent != "1")&(CurrParent != "Cl1")){
            Which <- which(Child==CurrParent)
            Path[[ii]] <- c(Path[[ii]], CurrParent)
            CurrParent <- Parent[Which]
        }
        Path[[ii]] <- c(Path[[ii]], CurrParent)
    }

    #Find the common part of these 2 paths
    Common <- Path[[1]][Path[[1]]%in%Path[[2]]]

    Path <- invisible(lapply(Path, function(u){
        u <- u[1:(length(u)-length(Common)+1)]
    }))

    Fst = sapply(Path, function(u){
        ListTheta <- list()
        for (ii in 1:(length(u)-1)){
            ListTheta[[ii]] <- 1-Theta[row.names(Theta)==paste(u[ii],u[ii+1],sep='-')]
        }
        return(1 - Reduce('*',ListTheta))
    })

    return(mean(Fst))
}

#' MakeItSym
#'
#' @param Mat A real square matrix
#' @description Transform a upper triangle matrix into a symmetric matrix
#' @return A real square matrix
MakeItSym <- function(Mat){
    Mat[lower.tri(Mat)] <- t(Mat)[lower.tri(Mat)]
    return(Mat)
}

#' CountFiles2HFst
#'
#' @param FileList A list of strings containing the file names (including the path if needed)
#' @param NbIndPerPop A numeric vector or a matrix containing the sample sizes per pop.
#' @description Compute Bhatia's estimator of Hudson's Fst, using count data stored in RDS files.
#' @return An Fst matrix containing the moment estimates of the Hudson Fst coefficients for all pairs of populations.
#' @import dplyr
#' @import purrr
#' @import future
#' @import furrr
#' @import stringr
#' @export
#' @examples
#' FN <- system.file("extdata", "CountData_Chr22_sample.rds", package = "HFst")
#' data("NbGamPerPop")
#' CountFiles2HFst(FN,NbGamPerPop)
CountFiles2HFst <- function(FileList,NbIndPerPop){

  ## Checks on NbIndPerPop
  if((!is.numeric(NbIndPerPop))&(!is.matrix(NbIndPerPop))){
    stop('NbIndPerPop should be a numeric vector or matrix')
  }
  if(is.null(names(NbIndPerPop))){
    stop('Objects in NbIndPerPop should be named')
  }
  NbPoploc <- length(NbIndPerPop)

  ## Checks on FileList
  Extension <- FileList %>%
    str_split(pattern='\\.') %>%
    map_chr(~.x[[length(.x)]]) %>%
    unique %>%
    tolower
  if(length(Extension)>1){
    stop('Only 1 extension (.rds OR .txt) allowed')
  }
  if(!(Extension%in%c('txt','rds'))){
    stop('Only .rds and .txt extensions allowed.')
  }
  if(Extension=='rds'){
    FunctionToReadData <- readRDS
  } else {
    FunctionToReadData <- fread
  }

  plan(strategy = 'multisession')
  Res <- future_map(FileList, ~{
    EmpFreqloc <- FunctionToReadData(.x) %>%
      as.matrix %>%
     {sapply(1:NbPoploc, function(u) .[,u]/NbIndPerPop[u])}
    Add <- crossprod(EmpFreqloc,1-EmpFreqloc) + crossprod(1-EmpFreqloc,EmpFreqloc)
    Self <- colSums(EmpFreqloc*(1-EmpFreqloc))*NbIndPerPop/(NbIndPerPop-1)
    Den <- Add
    Num <- Add - Self - tcrossprod(rep(1,NbPoploc),Self)
    return(list(Den=Den,Num=Num))
  })
  plan(strategy = 'default')
  Num <- map(Res,~.x$Num) %>% Reduce('+',.)
  Den <- map(Res,~.x$Den) %>% Reduce('+',.)
  Fst <- (Num/Den)
  row.names(Fst) <- colnames(Fst) <- names(NbIndPerPop)
  diag(Fst) <- 0
  return(Fst)

}


#' CountFiles2Moments
#'
#' @param FileList A list of strings containing the file names (including the path if needed)
#' @param NbIndPerPop A numeric vector or a matrix containing the sample sizes per pop.
#' @description Compute the moments required for the HFst.clust function from count files and the sample sizes in each population.
#' @return A non-symmetric moment matrix. Each element \eqn{i,j} contains the H-moment between populations \eqn{i} and \eqn{j}.
#' @import dplyr
#' @import purrr
#' @import future
#' @import furrr
#' @import stringr
#' @importFrom data.table fread
#' @export
#' @examples
#' FN <- system.file("extdata", "CountData_Chr22_sample.rds", package = "HFst")
#' data("NbGamPerPop")
#' CountFiles2Moments(FN,NbGamPerPop)
CountFiles2Moments <- function(FileList,NbIndPerPop){

  ## Checks on NbIndPerPop
  if((!is.numeric(NbIndPerPop))&(!is.matrix(NbIndPerPop))){
    stop('NbIndPerPop should be a numeric vector or matrix')
  }
  if(is.null(names(NbIndPerPop))){
    stop('Objects in NbIndPerPop should be named')
  }
  NbPoploc <- length(NbIndPerPop)

  ## Checks on FileList
  Extension <- FileList %>%
    str_split(pattern='\\.') %>%
    map_chr(~.x[[length(.x)]]) %>%
    unique %>%
    tolower
  if(length(Extension)>1){
    stop('Only 1 extension (.rds OR .txt) allowed')
  }
  if(!(Extension%in%c('txt','rds'))){
    stop('Only .rds and .txt extensions allowed.')
  }
  if(Extension=='rds'){
    FunctionToReadData <- readRDS
  } else {
    FunctionToReadData <- fread
  }

  Num <- Den <- 0
  NbPoploc <- length(NbIndPerPop)
  plan(strategy = "multisession")
  Res <- future_map(FileList, ~{
    EmpFreqloc <- FunctionToReadData(.x) %>%
      as.data.frame %>%
      {sapply(1:NbPoploc, function(u) .[,u]/NbIndPerPop[u])}
    Den <- 0.5*(crossprod(EmpFreqloc,1-EmpFreqloc) + crossprod(1-EmpFreqloc,EmpFreqloc))
    Num <- matrix(colSums(EmpFreqloc*(1-EmpFreqloc))*NbIndPerPop/(NbIndPerPop-1),NbPoploc,NbPoploc)
    return(list(Den=Den,Num=Num))
  })
  plan(strategy = "default")
  Num <- map(Res, ~ .x$Num) %>% Reduce('+',.)
  Den <- map(Res, ~ .x$Den) %>% Reduce('+',.)
  Fst <- Num/Den
  diag(Fst) <- 0
  row.names(Fst) <- colnames(Fst) <- names(NbIndPerPop)

  return(Fst)

}


#' HTree2HFst
#'
#' @param HTree An HTree as obtained from the HFst.clust function
#' @return A matrix of Hudson estimates computed from the HTree object
#' @export
#' @examples
#' data(LogMoment.mat)
#' HTree <- HFst.clust(LogMoments=LogMoment.mat,Improve=FALSE)
#' HTree2HFst(HTree)
HTree2HFst <- function(HTree){

  ## Check the HTree object
  if(!is.list(HTree)){
    stop('HTree should be a list as obtained from the HFst.clust function')
  } else {
    if(map_lgl(c("Tree","ThetaHat","Hist","Fst","Crit"), ~ !(.x%in%names(HTree))) %>% any){
      stop('HTree should be a list as obtained from the HFst.clust function')
    }
  }

  ## Get Hudson Fst matrix
  PopNames <- HTree$Fst %>% colnames
  NbPop <- length(PopNames)
  FstMat <- matrix(0,NbPop,NbPop)
  ListPairs <- combn(PopNames,2,simplify = F)
  invisible(sapply(ListPairs, function(u){
    FstMat[which(PopNames==u[1]),which(PopNames==u[2])] <<- FstHudson(u,as.data.frame(HTree$Tree),HTree$ThetaHat)
  }))
  FstMat <- MakeItSym(FstMat)
  rownames(FstMat) <- colnames(FstMat) <- PopNames
  return(FstMat)

}


#' Plot.HTree
#'
#' @param HTree An HTree as obtained from the HFst function
#' @param DF.col A data.frame with 2 columns, "Pop" and "Col", optional.
#' @param GetOrdering A boolean to get the ordering
#' @import ggtree
#' @importFrom ape read.tree
#' @import ggplot2
#' @import ggdendro
#' @import tibble
#'
#' @return A ggplot object
#' @export
#' @examples
#' data(LogMoment.mat)
#' HTree <- HFst.clust(LogMoments=LogMoment.mat,Improve=FALSE)
#' Plot.HTree(HTree)
Plot.HTree <- function(HTree,DF.col=NULL,GetOrdering=FALSE){

  ## Check the TreeHFst object
  if(!is.list(HTree)){
    stop('HTree should be a list as obtained from the HFstTree function')
  } else {
    if(map_lgl(c("Tree","ThetaHat","Hist","Fst","Crit"), ~ !(.x%in%names(HTree))) %>% any){
      stop('HTree should be a list as obtained from the ClustWeightedHFst function')
    }
  }

  ## Check the DF.col object
  if(is.null(DF.col)){
    DF.col <- tibble(Pop=colnames(HTree$Fst),Col='black')
  } else {
    if((!is.data.frame(DF.col))&(!is_tibble(DF.col))){
      stop('DF.col should be either a tibble or a data.frame')
    } else {
      if(map_lgl(c('Pop','Col'), ~ !(.x%in%names(DF.col))) %>% any){
        stop('DF.col should have both a Pop and a Col column')
      }
    }
  }


  ## Build a tree as required by the ape package
  Hist <- HTree$Hist
  TH <- HTree$ThetaHat
  NbPop <- ncol(HTree$Fst)
  ClusDesc <- as.list(rep(NA,NbPop-1))
  names(ClusDesc) <- Hist[,1]
  invisible(sapply(1:nrow(Hist), function(clust){
    ClusName <- as.character(Hist[clust,1])
    Member1 <- Hist[clust,2]
    Member2 <- Hist[clust,3]
    ThetaMember1 <- TH[row.names(TH)==paste(Member1,ClusName,sep='-')]
    ThetaMember2 <- TH[row.names(TH)==paste(Member2,ClusName,sep='-')]
    if (substr(Member1,1,2)=='Cl'){
      Member1 <- ClusDesc[[Member1]]
    }
    if (substr(Member2,1,2)=='Cl'){
      Member2 <- ClusDesc[[Member2]]
    }
    NewClus <- paste0('(',Member1,':',ThetaMember1,',',Member2,':',ThetaMember2,')')
    ClusDesc[[ClusName]] <<- NewClus
    #ClusDesc[[ClusName]] <<- NewClus
  }))
  ClusDesc2 <- ClusDesc
  names(ClusDesc2) <- paste0('Cl',length(ClusDesc):1)
  tree<-ape::read.tree(text=paste0(ClusDesc[[length(ClusDesc)]],';'))
  if(GetOrdering){
    d <- fortify(tree)
    d <- d[which(d$isTip),]
    Ordering <- with(d, label[order(y, decreasing=T)])
  }

  ## Provide the color associated to each pop
  ColPerPop <- left_join(tibble(Pop=tree$tip.label),DF.col,by='Pop') %>%
    dplyr::select('Pop','Col') %>%
    deframe()

  ## Display the tree
  GG <- ggtree(tree, size=1.5) +
    theme_tree2() +
    geom_tiplab(colour=ColPerPop,size=5) +
    #scale_x_continuous(limits=c(0,2*max(tree$edge.length))) +
    theme(axis.text.x = element_text(size = 17),
          axis.ticks.x=element_line(size=2),
          element_line(size=2,linetype = "solid"))

  if(GetOrdering){
    return(list(GGtree=GG,Ordering=Ordering))
  } else {
    return(GG)
  }

}
