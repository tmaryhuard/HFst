
#' Matrix of Hudson Fst estimates for the 1KG dataset
#'
#' HFst.mat is a square matrix providing the  Hudson Fst estimates between the 22 populations
#' of the 1KG dataset, based on chromosome 22 only. It is provided to illustrate some functions
#' of the packages.
#'
#' @format A matrix
#'
"HFst.mat"

#' Matrix of log-moments for the 1KG dataset
#'
#' LogMoment.mat is a square matrix providing the Log-moments (as computed by the [CountFiles2Moments()] function) between the 22 populations
#' of the 1KG dataset, based on chromosome 22 only. It is provided to illustrate some functions
#' of the packages.
#'
#' @format A matrix
#'
"LogMoment.mat"



#' Vector of sample size for the 1KG dataset
#'
#' NbGamPerPop is a vector providing the number of gametes available for each of the 22 populations
#' of the 1KG dataset. It is provided to illustrate some functions
#' of the packages.
#'
#' @format A matrix
#'
"NbGamPerPop"
