#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(BH)]]


using namespace Rcpp;
using namespace arma;


int Ind_Max(vec v){
  int IndMax = 0;
  double Max = v[0];
  for (unsigned int i=0; i<v.size(); i++){
    if (v[i]>Max){
      IndMax=i;
      Max=v[i];
    }
  }
  return IndMax;
}


//Non Negative Least Squares
//' @title NNLScpp
//'
//' @description Perform Non Negative Least Squares
//' @param X a \eqn{(n,p)} real matrix
//' @param Y a vector of size \eqn{n}
//' @param Init a vector of size \eqn{p}
//' @return a list of 4 elements: BetaHat, SSq, Residuals and W
//' @export
// [[Rcpp::export]]
List NNLScpp(arma::mat X, arma::vec Y, arma::vec Init){

  //Basic quantities
  int p = X.n_cols;
  vec VarList = linspace<vec>(0, p-1, p); // A virer ulterieurement ?
  vec covXY = trans(X)*Y;
  mat covX = trans(X)*X;
  vec Beta0 = zeros<vec>(p) ;

  //Initialization
  vec BetaNew = Init;
  vec W = covXY - covX*BetaNew;
  int IndMax = Ind_Max(W);
  uvec ZeroSet = find(BetaNew==0);
  uvec PosSet = find(BetaNew);
  double MinB ;
  double Alpha ;
  uvec Qui;

  //Loop
  while((W[IndMax]>1e-10)&(ZeroSet.size()>0)){
    vec BetaOld = BetaNew;
    PosSet.resize(PosSet.size()+1);
    PosSet(PosSet.size()-1) = IndMax;
    PosSet = sort(unique(PosSet));
    ZeroSet = ZeroSet(find(ZeroSet != IndMax));
    BetaNew = Beta0;
    BetaNew(PosSet) = solve( covX(PosSet,PosSet) , covXY(PosSet) );
    MinB = min(BetaNew);

    if (MinB<0){
      Qui = find(BetaNew<0);
      Alpha = min((BetaOld(Qui)/(BetaOld(Qui)-BetaNew(Qui))));
      BetaNew = (1-Alpha)*BetaOld + Alpha*BetaNew ;
      BetaNew.elem( find(abs(BetaNew)<1e-14) ).zeros() ;
      PosSet = find(BetaNew);
      ZeroSet = find(BetaNew==0);

    }

    W = covXY - covX*BetaNew;
    IndMax = Ind_Max(W);

  }

  vec Residuals = Y-X*BetaNew;
  double Crit = sum(square(Residuals)) ;
  return List::create(
    Rcpp::Named("BetaHat") = BetaNew,
    Rcpp::Named("SSq") = Crit,
    Rcpp::Named("Residuals") = Residuals,
    Rcpp::Named("W") = W
  );
}

//NNLS <- function(X,Y,Init=NULL){
//
//    #Basic quantities
//    p <- ncol(X)
//    VarList <- 1:p
//    covXY <- crossprod(X,Y)
//    covX <- crossprod(X)
//    Beta0 <- rep(0,p)
//
//    #Initialisation
//    if (is.null(Init)){
//        BetaNew <- Beta0
//        W <- covXY
//    } else {
//        BetaNew <- Init
//        W <- covXY - crossprod(covX,BetaNew)
//    }
//    ZeroSet <- which(BetaNew==0)
//    PosSet <- setdiff(VarList,ZeroSet)
//    IndMax <- which.max(W)
//
//    while((W[IndMax]>1e-10)&(!is.null(ZeroSet))){
//        BetaOld <- BetaNew
//        PosSet <- sort(unique(c(PosSet,IndMax)))
//        ZeroSet <- setdiff(ZeroSet,IndMax)
//        BetaNew <- Beta0
//        BetaNew[PosSet] <- solve(crossprod(X[,PosSet]),crossprod(X[,PosSet],Y))
//        MinB <- min(BetaNew)
//        if (MinB<0){
//            Qui <- which(BetaNew<0)
//            Alpha <- min((BetaOld/(BetaOld-BetaNew))[Qui])
//            BetaNew <- (1-Alpha)*BetaOld + Alpha*BetaNew
//            BetaNew[abs(BetaNew)<1e-14] <- 0
//            PosSet <- which(BetaNew>0)
//            ZeroSet <- setdiff(VarList,PosSet)
//        }
//        W <- covXY - crossprod(covX,BetaNew)
//        IndMax <- which.max(W)
//    }
//    Crit <- crossprod(Y-X%*%BetaNew)
//    return(list(Beta=BetaNew,Crit=Crit,W=W))
//}
